Citizen.CreateThread(function()
	LoadMpDlcMaps()
	EnableMpDlcMaps(true)
	RequestIpl("coronertrash")
	RequestIpl("Coroner_Int_On")
	RequestIpl("chop_props")
	RemoveIpl("hei_bi_hw1_13_door")
	RequestIpl("v_rockclub")
	
	RequestIpl("rc12b_default")
	RequestIpl("rc12b_hospitalinterior")
	RequestIpl("rc12b_destroyed")

	RemoveIpl("v_carshowroom")
	RemoveIpl("shutter_open")
	RemoveIpl("shutter_closed")
	RemoveIpl("shr_int")
	RemoveIpl("csr_inMission")
	RequestIpl("v_carshowroom")
	RequestIpl("shr_int")
	RequestIpl("shutter_closed")
	RequestIpl("FINBANK")
	RemoveIpl("facelobbyfake")
	RequestIpl("facelobby")
	RemoveIpl("CS1_02_cf_offmission")
	RequestIpl("CS1_02_cf_onmission1")
	RequestIpl("CS1_02_cf_onmission2")
	RequestIpl("CS1_02_cf_onmission3")
	RequestIpl("CS1_02_cf_onmission4")

	RemoveIpl("farmint")
	RemoveIpl("farm_burnt")
	RemoveIpl("farm_burnt_props")
	RemoveIpl("des_farmhs_endimap")
	RemoveIpl("des_farmhs_end_occl")

	RequestIpl("farm")
	RequestIpl("farm_props")
	RequestIpl("farm_int")

	RequestIpl("des_farmhouse")
	RequestIpl("des_farmhs_startimap")
	RequestIpl("des_farmhs_start_occl")
	RequestIpl("farmint_cap")
	RequestIpl("FIBlobby")
	RemoveIpl("FIBlobbyfake")
	RequestIpl("FBI_colPLUG")
	RequestIpl("FBI_repair")
	RemoveIpl("id2_14_during_door")
	RemoveIpl("id2_14_during2")
	RemoveIpl("id2_14_on_fire")
	RemoveIpl("id2_14_post_no_int")
	RemoveIpl("id2_14_pre_no_int")
	RequestIpl("id2_14_during1")
	RequestIpl("TrevorsMP")
	RequestIpl("TrevorsTrailer")
	RequestIpl("TrevorsTrailerTidy")
	RequestIpl("TrevorsTrailerTrash")
	RemoveIpl("DT1_03_Gr_Closed")
	RemoveIpl("DT1_03_Shutter")
	RequestIpl("yogagame")
	RequestIpl("v_tunnel_hole")
	RequestIpl("V_Michael")
	RequestIpl("V_Michael_Garage")
	RequestIpl("V_Michael_FameShame")
	RequestIpl("V_Michael_JewelHeist")
	RequestIpl("V_Michael_plane_ticket")
	RequestIpl("V_Michael_Scuba")
	RemoveIpl("smboat")
	RequestIpl("hei_yacht_heist")
	RequestIpl("hei_yacht_heist_Bar")
	RequestIpl("hei_yacht_heist_Bedrm")
	RequestIpl("hei_yacht_heist_Bridge")
	RequestIpl("hei_yacht_heist_DistantLights")
	RequestIpl("hei_yacht_heist_enginrm")
	RequestIpl("hei_yacht_heist_LODLights")
	RequestIpl("hei_yacht_heist_Lounge")
	RequestIpl("cargoship")
	RemoveIpl("sp1_10_fake_interior")
	RemoveIpl("sp1_10_fake_interior_lod")
	RequestIpl("railing_start")
	RequestIpl("railing_end")
	RequestIpl("SC1_01_NewBill")
	RequestIpl("hw1_02_newbill")
	RequestIpl("hw1_emissive_newbill")
	RequestIpl("sc1_14_newbill")
	RequestIpl("dt1_17_newbill")
	RequestIpl("SC1_01_OldBill")
	RequestIpl("SC1_30_Keep_Closed")
	RequestIpl("refit_unload")
	RequestIpl("post_hiest_unload")
	RequestIpl("occl_meth_grp1")
	RequestIpl("Michael_premier")
	RemoveIpl("DT1_05_HC_REMOVE")
	RequestIpl("DT1_05_HC_REQ")
	RequestIpl("DT1_05_REQUEST")
	RemoveIpl("jewel2fake")
	RemoveIpl("bh1_16_refurb")
	RemoveIpl("ch1_02_closed")
	RemoveIpl("scafstartimap")
	RequestIpl("scafendimap")
	RemoveIpl("bh1_16_doors_shut")
	RequestIpl("ferris_finale_Anim")
	RequestIpl("des_stilthouse_rebuild")
	RequestIpl("CS2_06_TriAf02")
	--RequestIpl("cs3_07_mpgates")
	RequestIpl("CS4_08_TriAf02")
	RequestIpl("CS4_04_TriAf03")
	RequestIpl("AP1_04_TriAf01")
	RequestIpl("gr_case0_bunkerclosed")
	RequestIpl("gr_case1_bunkerclosed")
	RequestIpl("gr_case2_bunkerclosed")
	RequestIpl("gr_case3_bunkerclosed")
	RequestIpl("gr_case4_bunkerclosed")
	RequestIpl("gr_case5_bunkerclosed")
	RequestIpl("gr_case6_bunkerclosed")
	RequestIpl("gr_case7_bunkerclosed")
	RequestIpl("gr_case9_bunkerclosed")
	RequestIpl("gr_case10_bunkerclosed")
	RequestIpl("gr_case11_bunkerclosed")
	RequestIpl("cs5_4_trains")
	RequestIpl("chophillskennel")
	RequestIpl("bnkheist_apt_dest")
	RequestIpl("bnkheist_apt_norm")
	RemoveIpl("redcarpet")
	RequestIpl("hei_sm_16_interior_v_bahama_milo_")
	RequestIpl("cs3_05_water_grp1")
	RequestIpl("cs3_05_water_grp1_lod")
	RequestIpl("cs3_05_water_grp2")
	RequestIpl("cs3_05_water_grp2_lod")
	RequestIpl("canyonriver01")
	RequestIpl("canyonriver01_lod")
	RequestIpl("bh1_47_joshhse_unburnt")
	RequestIpl("bh1_47_joshhse_unburnt_lod")
	RequestIpl("bkr_bi_hw1_13_int")
	RequestIpl("CanyonRvrShallow")
	RequestIpl("methtrailer_grp1")
	RequestIpl("lr_cs6_08_grave_closed")
	RequestIpl("bkr_bi_id1_23_door")
	RequestIpl("ch1_02_open")
	RequestIpl("sp1_10_real_interior")
	RequestIpl("sp1_10_real_interior_lod")
	RequestIpl("Carwash_with_spinners")
	RequestIpl("apa_v_mp_h_01_a")
	RequestIpl("apa_v_mp_h_06_b")
	RequestIpl("apa_v_mp_h_08_c")
	RequestIpl("ex_dt1_02_office_01c")
	RequestIpl("ex_dt1_11_office_01b")
	RequestIpl("ex_sm_13_office_01a")
	RequestIpl("ex_sm_15_office_02b")
	RequestIpl("bkr_biker_interior_placement_interior_0_biker_dlc_int_01_milo")
	RequestIpl("bkr_biker_interior_placement_interior_1_biker_dlc_int_02_milo")
	RequestIpl("bkr_biker_interior_placement_interior_2_biker_dlc_int_ware01_milo")
	RequestIpl("bkr_biker_interior_placement_interior_2_biker_dlc_int_ware02_milo")
	RequestIpl("bkr_biker_interior_placement_interior_2_biker_dlc_int_ware03_milo")
	RequestIpl("bkr_biker_interior_placement_interior_2_biker_dlc_int_ware04_milo")
	RequestIpl("bkr_biker_interior_placement_interior_2_biker_dlc_int_ware05_milo")
	RequestIpl("bkr_biker_interior_placement_interior_3_biker_dlc_int_ware02_milo")
	RequestIpl("bkr_biker_interior_placement_interior_4_biker_dlc_int_ware03_milo")
	RequestIpl("bkr_biker_interior_placement_interior_5_biker_dlc_int_ware04_milo")
	RequestIpl("bkr_biker_interior_placement_interior_6_biker_dlc_int_ware05_milo")
	RequestIpl("ex_exec_warehouse_placement_interior_1_int_warehouse_s_dlc_milo")
	RequestIpl("ex_exec_warehouse_placement_interior_0_int_warehouse_m_dlc_milo")
	RequestIpl("ex_exec_warehouse_placement_interior_2_int_warehouse_l_dlc_milo")
	RequestIpl("imp_impexp_interior_placement")
	RequestIpl("imp_impexp_interior_placement_interior_0_impexp_int_01_milo_")
	RequestIpl("imp_impexp_interior_placement_interior_1_impexp_intwaremed_milo_")
	RequestIpl("imp_impexp_interior_placement_interior_2_imptexp_mod_int_01_milo_")
	RequestIpl("imp_impexp_interior_placement_interior_3_impexp_int_02_milo_")
	RequestIpl("gr_case0_bunkerclosed")
	RequestIpl("gr_case1_bunkerclosed")
	RequestIpl("gr_case2_bunkerclosed")
	RequestIpl("gr_case3_bunkerclosed")
	RequestIpl("gr_case4_bunkerclosed")
	RequestIpl("gr_case5_bunkerclosed")
	RequestIpl("gr_case6_bunkerclosed")
	RequestIpl("gr_case7_bunkerclosed")
	RequestIpl("gr_case9_bunkerclosed")
	RequestIpl("gr_case10_bunkerclosed")
	RequestIpl("gr_case11_bunkerclosed")
	RequestIpl("gr_entrance_placement")
	RequestIpl("gr_grdlc_interior_placement")
	RequestIpl("gr_grdlc_interior_placement_interior_0_grdlc_int_01_milo_")
	RequestIpl("gr_grdlc_interior_placement_interior_1_grdlc_int_02_milo_")
	RequestIpl("ch3_rd2_bishopschickengraffiti")
	RequestIpl("cs5_04_mazebillboardgraffiti")
	RequestIpl("cs5_roads_ronoilgraffiti")
	RequestIpl("ba_barriers_case0")
	RequestIpl("ba_case0_forsale")
	RequestIpl("ba_case0_dixon")
	RequestIpl("ba_case0_madonna")
	RequestIpl("ba_case0_solomun")
	RequestIpl("ba_case0_taleofus")
	RequestIpl("ba_barriers_case1")
	RequestIpl("ba_case1_forsale")
	RequestIpl("ba_case1_dixon")
	RequestIpl("ba_case1_madonna")
	RequestIpl("ba_case1_solomun")
	RequestIpl("ba_case1_taleofus")
	RequestIpl("ba_barriers_case2")
	RequestIpl("ba_case2_forsale")
	RequestIpl("ba_case2_dixon")
	RequestIpl("ba_case2_madonna")
	RequestIpl("ba_case2_solomun")
	RequestIpl("ba_case2_taleofus")
	RequestIpl("ba_barriers_case3")
	RequestIpl("ba_case3_forsale")
	RequestIpl("ba_case3_dixon")
	RequestIpl("ba_case3_madonna")
	RequestIpl("ba_case3_solomun")
	RequestIpl("ba_case3_taleofus")
	RequestIpl("ba_barriers_case4")
	RequestIpl("ba_case4_forsale")
	RequestIpl("ba_case4_dixon")
	RequestIpl("ba_case4_madonna")
	RequestIpl("ba_case4_solomun")
	RequestIpl("ba_case4_taleofus")
	RequestIpl("ba_barriers_case5")
	RequestIpl("ba_case5_forsale")
	RequestIpl("ba_case5_dixon")
	RequestIpl("ba_case5_madonna")
	RequestIpl("ba_case5_solomun")
	RequestIpl("ba_case5_taleofus")
	RequestIpl("ba_barriers_case6")
	RequestIpl("ba_case6_forsale")
	RequestIpl("ba_case6_dixon")
	RequestIpl("ba_case6_madonna")
	RequestIpl("ba_case6_solomun")
	RequestIpl("ba_case6_taleofus")
	RequestIpl("ba_barriers_case7")
	RequestIpl("ba_case7_forsale")
	RequestIpl("ba_case7_dixon")
	RequestIpl("ba_case7_madonna")
	RequestIpl("ba_case7_solomun")
	RequestIpl("ba_case7_taleofus")
	RequestIpl("ba_barriers_case8")
	RequestIpl("ba_case8_forsale")
	RequestIpl("ba_case8_dixon")
	RequestIpl("ba_case8_madonna")
	RequestIpl("ba_case8_solomun")
	RequestIpl("ba_case8_taleofus")
	RequestIpl("ba_barriers_case9")
	RequestIpl("ba_case9_forsale")
	RequestIpl("ba_case9_dixon")
	RequestIpl("ba_case9_madonna")
	RequestIpl("ba_case9_solomun")
	RequestIpl("ba_case9_taleofus")
	RequestIpl("gr_grdlc_yacht_lod")
	RequestIpl("gr_grdlc_yacht_placement")
	RequestIpl("gr_heist_yacht2")
	RequestIpl("gr_heist_yacht2_bar")
	RequestIpl("gr_heist_yacht2_bar_lod")
	RequestIpl("gr_heist_yacht2_bedrm")
	RequestIpl("gr_heist_yacht2_bedrm_lod")
	RequestIpl("gr_heist_yacht2_bridge")
	RequestIpl("gr_heist_yacht2_bridge_lod")
	RequestIpl("gr_heist_yacht2_enginrm")
	RequestIpl("gr_heist_yacht2_enginrm_lod")
	RequestIpl("gr_heist_yacht2_lod")
	RequestIpl("gr_heist_yacht2_lounge")
	RequestIpl("gr_heist_yacht2_lounge_lod")
	RequestIpl("gr_heist_yacht2_slod")
	
	-- teste da ilha h4_islandairstrip
	RequestIpl("h4_islandairstrip")
    RequestIpl("h4_islandairstrip_props")
    RequestIpl("h4_islandx_mansion")
    RequestIpl("h4_islandx_mansion_props")
    RequestIpl("h4_islandx_props")
    RequestIpl("h4_islandxdock")
    RequestIpl("h4_islandxdock_props")
    RequestIpl("h4_islandxdock_props_2")
    RequestIpl("h4_islandxtower")
    RequestIpl("h4_islandx_maindock")
    RequestIpl("h4_islandx_maindock_props")
    RequestIpl("h4_islandx_maindock_props_2")
    RequestIpl("h4_IslandX_Mansion_Vault")
    RequestIpl("h4_islandairstrip_propsb")
    RequestIpl("h4_beach")
    RequestIpl("h4_beach_props")
    RequestIpl("h4_beach_bar_props")
    RequestIpl("h4_islandx_barrack_props")
    RequestIpl("h4_islandx_checkpoint")
    RequestIpl("h4_islandx_checkpoint_props")
    RequestIpl("h4_islandx_Mansion_Office")
    RequestIpl("h4_islandx_Mansion_LockUp_01")
    RequestIpl("h4_islandx_Mansion_LockUp_02")
    RequestIpl("h4_islandx_Mansion_LockUp_03")
    RequestIpl("h4_islandairstrip_hangar_props")
    RequestIpl("h4_IslandX_Mansion_B")
    RequestIpl("h4_islandairstrip_doorsclosed")
    RequestIpl("h4_Underwater_Gate_Closed")
    RequestIpl("h4_mansion_gate_closed")
    RequestIpl("h4_aa_guns")
    RequestIpl("h4_IslandX_Mansion_GuardFence")
    RequestIpl("h4_IslandX_Mansion_Entrance_Fence")
    RequestIpl("h4_IslandX_Mansion_B_Side_Fence")
    RequestIpl("h4_IslandX_Mansion_Lights")
    RequestIpl("h4_islandxcanal_props")
    RequestIpl("h4_beach_props_party")
    RequestIpl("h4_islandX_Terrain_props_06_a")
    RequestIpl("h4_islandX_Terrain_props_06_b")
    RequestIpl("h4_islandX_Terrain_props_06_c")
    RequestIpl("h4_islandX_Terrain_props_05_a")
    RequestIpl("h4_islandX_Terrain_props_05_b")
    RequestIpl("h4_islandX_Terrain_props_05_c")
    RequestIpl("h4_islandX_Terrain_props_05_d")
    RequestIpl("h4_islandX_Terrain_props_05_e")
    RequestIpl("h4_islandX_Terrain_props_05_f")
    RequestIpl("H4_islandx_terrain_01")
    RequestIpl("H4_islandx_terrain_02")
    RequestIpl("H4_islandx_terrain_03")
    RequestIpl("H4_islandx_terrain_04")
    RequestIpl("H4_islandx_terrain_05")
    RequestIpl("H4_islandx_terrain_06")
    RequestIpl("h4_ne_ipl_00")
    RequestIpl("h4_ne_ipl_01")
    RequestIpl("h4_ne_ipl_02")
    RequestIpl("h4_ne_ipl_03")
    RequestIpl("h4_ne_ipl_04")
    RequestIpl("h4_ne_ipl_05")
    RequestIpl("h4_ne_ipl_06")
    RequestIpl("h4_ne_ipl_07")
    RequestIpl("h4_ne_ipl_08")
    RequestIpl("h4_ne_ipl_09")
    RequestIpl("h4_nw_ipl_00")
    RequestIpl("h4_nw_ipl_01")
    RequestIpl("h4_nw_ipl_02")
    RequestIpl("h4_nw_ipl_03")
    RequestIpl("h4_nw_ipl_04")
    RequestIpl("h4_nw_ipl_05")
    RequestIpl("h4_nw_ipl_06")
    RequestIpl("h4_nw_ipl_07")
    RequestIpl("h4_nw_ipl_08")
    RequestIpl("h4_nw_ipl_09")
    RequestIpl("h4_se_ipl_00")
    RequestIpl("h4_se_ipl_01")
    RequestIpl("h4_se_ipl_02")
    RequestIpl("h4_se_ipl_03")
    RequestIpl("h4_se_ipl_04")
    RequestIpl("h4_se_ipl_05")
    RequestIpl("h4_se_ipl_06")
    RequestIpl("h4_se_ipl_07")
    RequestIpl("h4_se_ipl_08")
    RequestIpl("h4_se_ipl_09")
    RequestIpl("h4_sw_ipl_00")
    RequestIpl("h4_sw_ipl_01")
    RequestIpl("h4_sw_ipl_02")
    RequestIpl("h4_sw_ipl_03")
    RequestIpl("h4_sw_ipl_04")
    RequestIpl("h4_sw_ipl_05")
    RequestIpl("h4_sw_ipl_06")
    RequestIpl("h4_sw_ipl_07")
    RequestIpl("h4_sw_ipl_08")
    RequestIpl("h4_sw_ipl_09")
    RequestIpl("h4_islandx_mansion")
    RequestIpl("h4_islandxtower_veg")
    RequestIpl("h4_islandx_sea_mines")
    RequestIpl("h4_islandx")
    RequestIpl("h4_islandx_barrack_hatch")
    RequestIpl("h4_islandxdock_water_hatch")
    RequestIpl("h4_beach_party")
    SetDeepOceanScaler(0.0)
end)


-- Citizen.CreateThread(function()
 
--     LoadMpDlcMaps()
--     EnableMpDlcMaps(true)

--     RequestIpl('vw_casino_billboard')
--     RequestIpl('vw_casino_billboard_lod(1)')
--     RequestIpl('vw_casino_billboard_lod')
--     RequestIpl('vw_casino_carpark')
--     RequestIpl('vw_casino_garage')
--     RequestIpl('vw_casino_main')
--     RequestIpl('vw_casino_penthouse')
--     RequestIpl('vw_ch3_additions')
--     RequestIpl('vw_ch3_additions_long_0')
--     RequestIpl('vw_ch3_additions_strm_0')
--     RequestIpl('vw_dlc_casino_door')
--     RequestIpl('vw_dlc_casino_door_lod')
--     RequestIpl('vw_int_placement_vw')
--     RequestIpl("vw_dlc_casino_apart")
--     RequestIpl("hei_dlc_casino_door")
--     RequestIpl("hei_dlc_windows_casino")

--     local phIntID = GetInteriorAtCoords(976.636, 70.295, 115.164)

--     EnableInteriorProp(phIntID, 'Set_Pent_Tint_Shell')
--     SetInteriorPropColor(phIntID, 'Set_Pent_Tint_Shell', 3)
--     EnableInteriorProp(phIntID, 'Set_Pent_Spa_Bar_Open')
--     EnableInteriorProp(phIntID, 'Set_Pent_Arcade_Retro')
--     EnableInteriorProp(phIntID, 'Set_Pent_bar_light_01')
--     EnableInteriorProp(phIntID, 'Set_Pent_bar_party_2')
--     EnableInteriorProp(phIntID, 'Set_Pent_Bar_Clutter')
--     EnableInteriorProp(phIntID, 'Set_Pent_Clutter_03')

--     RefreshInterior(phIntID)

-- end)

local EntitySetsTuner = {
	['entity_set_bedroom'] = true,
	['entity_set_bedroom_empty'] = true,
	['entity_set_bombs'] = true,
	['entity_set_box_clutter'] = false,
	['entity_set_cabinets'] = true,
	['entity_set_car_lift_cutscene'] = true,
	['entity_set_car_lift_default'] = true,
	['entity_set_car_lift_purchase'] = true,
	['entity_set_chalkboard'] = true,
	['entity_set_container'] = true,
	['entity_set_cut_seats'] = true,
	['entity_set_def_table'] = true,
	['entity_set_drive'] = true,
	['entity_set_ecu'] = true,
	['entity_set_IAA'] = true,
	['entity_set_jammers'] = true,
	['entity_set_laptop'] = true,
	['entity_set_lightbox'] = true,
	['entity_set_methLab'] = true,
	['entity_set_plate'] = true,
	['entity_set_scope'] = true,
	['entity_set_style_1'] = true,
	['entity_set_style_2'] = false,
	['entity_set_style_3'] = false,
	['entity_set_style_4'] = false,
	['entity_set_style_5'] = false,
	['entity_set_style_6'] = false,
	['entity_set_style_7'] = false,
	['entity_set_style_8'] = false,
	['entity_set_style_9'] = false,
	['entity_set_table'] = true,
	['entity_set_thermal'] = true,
	['entity_set_tints'] = true,
	['entity_set_train'] = true,
	['entity_set_virus'] = true,
}	
local entitySetsMeet = {
	['entity_set_meet_crew'] = true,
	['entity_set_meet_lights'] = true,
	['entity_set_meet_lights_cheap'] = true,
	['entity_set_player'] = true,
	['entity_set_test_crew'] = true,
	['entity_set_test_lights'] = true,
	['entity_set_test_lights_cheap'] = true,
	['entity_set_time_trial'] = true,
}	
local EntitySetMeth = {
	['tintable_walls'] = true,
}	  
Citizen.CreateThread(function()
	local tuna_interior_id = GetInteriorAtCoords(vector3(-1350.0, 160.0, -100.0))
	local meetup_interior_id = GetInteriorAtCoords(vector3(-2000.0, 1113.211, -25.36243))
	local methlab_interior_id = GetInteriorAtCoords(vector3(981.9999, -143.0, -50.0))
	RequestIpl('tr_tuner_meetup')
	RequestIpl('tr_tuner_race_line')
	RequestIpl('tr_tuner_shop_burton')
	RequestIpl('tr_tuner_shop_mesa' )
	RequestIpl('tr_tuner_shop_mission' )
	RequestIpl('tr_tuner_shop_rancho')
	RequestIpl('tr_tuner_shop_strawberry')		
	if IsValidInterior(tuna_interior_id) then
	  RefreshInterior(tuna_interior_id)
	end	
	if IsValidInterior(meetup_interior_id) then
		RefreshInterior(meetup_interior_id)
	end	
	if IsValidInterior(methlab_interior_id) then
		RefreshInterior(methlab_interior_id)
	end	
	for k, v in pairs(EntitySetsTuner) do
		if v then
			ActivateInteriorEntitySet(
				tuna_interior_id , 
				k 
			)
		else
			DeactivateInteriorEntitySet(
				tuna_interior_id , 
				k
			)
		end	
	end

	for k, v in pairs(entitySetsMeet) do
		if v then
			ActivateInteriorEntitySet(
				meetup_interior_id , 
				k 
			)
		else
			DeactivateInteriorEntitySet(
				meetup_interior_id , 
				k 
			)
		end
	end
	for k, v in pairs(EntitySetMeth) do
		if v then
			ActivateInteriorEntitySet(
				methlab_interior_id , 
				k 
			)
		else
			DeactivateInteriorEntitySet(
				methlab_interior_id , 
				k 
			)
		end
	end	
	SetInteriorEntitySetColor(284673, "tintable_walls", 2)
end)

-- Config = {}

-- Config.SetAudioFlag = true -- Activate the ambient sound
-- Config.OceanScaler = true -- Adjust the tide level

--Config.EnableRadar = true -- Display the island on the map

-- Config.Island = {
-- 		{ name = 'h4_islandairstrip_doorsopen', enabled = true },
-- 		{ name = 'h4_islandairstrip', enabled = true },
-- 		{ name = 'h4_islandairstrip_hangar_props', enabled = true },
-- 		{ name = 'h4_islandairstrip_props', enabled = true },
-- 		{ name = 'h4_islandairstrip_propsb', enabled = true },
-- 		{ name = 'h4_mph4_airstrip', enabled = true },
-- 		{ name = 'h4_mph4_airstrip_interior_0_airstrip_hanger', enabled = true },
		
-- 		{ name = 'h4_islandairstrip_doorsclosed', enabled = false },
-- 		{ name = 'h4_islandx_disc_strandedshark', enabled = false },
-- 		{ name = 'h4_islandx_disc_strandedwhale', enabled = false },
-- 		{ name = 'h4_islandx_sea_mines', enabled = false },
-- 		{ name = 'h4_mansion_gate_broken', enabled = false },
-- 		{ name = 'h4_underwater_gate_closed', enabled = false },
		
-- 		{ name = 'h4_mph4_terrain_01_grass_0', enabled = true },
-- 		{ name = 'h4_mph4_terrain_01_grass_1', enabled = true },
-- 		{ name = 'h4_mph4_terrain_02_grass_0', enabled = true },
-- 		{ name = 'h4_mph4_terrain_02_grass_1', enabled = true },
-- 		{ name = 'h4_mph4_terrain_02_grass_2', enabled = true },
-- 		{ name = 'h4_mph4_terrain_02_grass_3', enabled = true },
-- 		{ name = 'h4_mph4_terrain_04_grass_0', enabled = true },
-- 		{ name = 'h4_mph4_terrain_04_grass_1', enabled = true },
-- 		{ name = 'h4_mph4_terrain_05_grass_0', enabled = true },
-- 		{ name = 'h4_mph4_terrain_06_grass_0', enabled = true },
-- 		{ name = 'h4_islandx_terrain_01', enabled = true },
-- 		{ name = 'h4_islandx_terrain_02', enabled = true },
-- 		{ name = 'h4_islandx_terrain_03', enabled = true },
-- 		{ name = 'h4_islandx_terrain_04', enabled = true },
-- 		{ name = 'h4_islandx_terrain_05', enabled = true },
-- 		{ name = 'h4_islandx_terrain_06', enabled = true },
-- 		{ name = 'h4_islandx_terrain_props_05_a', enabled = true },
-- 		{ name = 'h4_islandx_terrain_props_05_b', enabled = true },
-- 		{ name = 'h4_islandx_terrain_props_05_c', enabled = true },
-- 		{ name = 'h4_islandx_terrain_props_05_d', enabled = true },
-- 		{ name = 'h4_islandx_terrain_props_05_e', enabled = true },
-- 		{ name = 'h4_islandx_terrain_props_05_f', enabled = true },
-- 		{ name = 'h4_islandx_terrain_props_06_a', enabled = true },
-- 		{ name = 'h4_islandx_terrain_props_06_b', enabled = true },
-- 		{ name = 'h4_islandx_terrain_props_06_c', enabled = true },
-- 		{ name = 'h4_mph4_terrain_01', enabled = true },
-- 		{ name = 'h4_mph4_terrain_01_long_0', enabled = true },
-- 		{ name = 'h4_mph4_terrain_02', enabled = true },
-- 		{ name = 'h4_mph4_terrain_03', enabled = true },
-- 		{ name = 'h4_mph4_terrain_04', enabled = true },
-- 		{ name = 'h4_mph4_terrain_05', enabled = true },
-- 		{ name = 'h4_mph4_terrain_06', enabled = true },
-- 		{ name = 'h4_mph4_terrain_06_strm_0', enabled = true },
-- 		{ name = 'h4_mph4_terrain_occ_00', enabled = true },
-- 		{ name = 'h4_mph4_terrain_occ_01', enabled = true },
-- 		{ name = 'h4_mph4_terrain_occ_02', enabled = true },
-- 		{ name = 'h4_mph4_terrain_occ_03', enabled = true },
-- 		{ name = 'h4_mph4_terrain_occ_04', enabled = true },
-- 		{ name = 'h4_mph4_terrain_occ_05', enabled = true },
-- 		{ name = 'h4_mph4_terrain_occ_06', enabled = true },
-- 		{ name = 'h4_mph4_terrain_occ_07', enabled = true },
-- 		{ name = 'h4_mph4_terrain_occ_08', enabled = true },
-- 		{ name = 'h4_mph4_terrain_occ_09', enabled = true },
-- 		{ name = 'h4_boatblockers', enabled = true },
-- 		{ name = 'h4_islandx', enabled = true },
-- 		{ name = 'h4_islandx_props', enabled = true },
-- 		{ name = 'h4_mph4_island', enabled = true },
-- 		{ name = 'h4_mph4_island_long_0', enabled = true },
-- 		{ name = 'h4_mph4_island_strm_0', enabled = true },
-- 		{ name = 'h4_aa_guns', enabled = true },
-- 		{ name = 'h4_beach', enabled = true },
-- 		{ name = 'h4_beach_bar_props', enabled = true },
-- 		{ name = 'h4_beach_party', enabled = true },
-- 		{ name = 'h4_beach_props', enabled = true },
-- 		{ name = 'h4_beach_props_party', enabled = true },
-- 		{ name = 'h4_islandxcanal_props', enabled = true },
-- 		{ name = 'h4_islandxdock', enabled = true },
-- 		{ name = 'h4_islandxdock_props', enabled = true },
-- 		{ name = 'h4_islandxdock_props_2', enabled = true },
-- 		{ name = 'h4_islandxdock_water_hatch', enabled = true },
-- 		{ name = 'h4_islandxtower', enabled = true },
-- 		{ name = 'h4_islandxtower_veg', enabled = true },
-- 		{ name = 'h4_islandx_barrack_hatch', enabled = true },
-- 		{ name = 'h4_islandx_barrack_props', enabled = true },
-- 		{ name = 'h4_islandx_checkpoint', enabled = true },
-- 		{ name = 'h4_islandx_checkpoint_props', enabled = true },
-- 		{ name = 'h4_islandx_maindock', enabled = true },
-- 		{ name = 'h4_islandx_maindock_props', enabled = true },
-- 		{ name = 'h4_islandx_maindock_props_2', enabled = true },
-- 		{ name = 'h4_islandx_mansion', enabled = true },
-- 		{ name = 'h4_islandx_mansion_b', enabled = true },
-- 		{ name = 'h4_islandx_mansion_b_side_fence', enabled = true },
-- 		{ name = 'h4_islandx_mansion_entrance_fence', enabled = true },
-- 		{ name = 'h4_islandx_mansion_guardfence', enabled = true },
-- 		{ name = 'h4_islandx_mansion_lights', enabled = true },
-- 		{ name = 'h4_islandx_mansion_lockup_01', enabled = true },
-- 		{ name = 'h4_islandx_mansion_lockup_02', enabled = true },
-- 		{ name = 'h4_islandx_mansion_lockup_03', enabled = true },
-- 		{ name = 'h4_islandx_mansion_office', enabled = true },
-- 		{ name = 'h4_islandx_mansion_props', enabled = true },
-- 		{ name = 'h4_islandx_mansion_vault', enabled = true },
-- 		{ name = 'h4_mansion_gate_closed', enabled = true },
-- 		{ name = 'h4_mansion_remains_cage', enabled = true },
-- 		{ name = 'h4_mph4_beach', enabled = true },
-- 		{ name = 'h4_mph4_dock', enabled = true },
-- 		{ name = 'h4_mph4_island_ne_placement', enabled = true },
-- 		{ name = 'h4_mph4_island_nw_placement', enabled = true },
-- 		{ name = 'h4_mph4_island_se_placement', enabled = true },
-- 		{ name = 'h4_mph4_island_sw_placement', enabled = true },
-- 		{ name = 'h4_mph4_mansion', enabled = true },
-- 		{ name = 'h4_mph4_mansion_b', enabled = true },
-- 		{ name = 'h4_mph4_mansion_b_strm_0', enabled = true },
-- 		{ name = 'h4_mph4_mansion_strm_0', enabled = true },
-- 		{ name = 'h4_mph4_wtowers', enabled = true },
-- 		{ name = 'h4_ne_ipl_00', enabled = true },
-- 		{ name = 'h4_ne_ipl_01', enabled = true },
-- 		{ name = 'h4_ne_ipl_02', enabled = true },
-- 		{ name = 'h4_ne_ipl_03', enabled = true },
-- 		{ name = 'h4_ne_ipl_04', enabled = true },
-- 		{ name = 'h4_ne_ipl_05', enabled = true },
-- 		{ name = 'h4_ne_ipl_06', enabled = true },
-- 		{ name = 'h4_ne_ipl_07', enabled = true },
-- 		{ name = 'h4_ne_ipl_08', enabled = true },
-- 		{ name = 'h4_ne_ipl_09', enabled = true },
-- 		{ name = 'h4_nw_ipl_00', enabled = true },
-- 		{ name = 'h4_nw_ipl_01', enabled = true },
-- 		{ name = 'h4_nw_ipl_02', enabled = true },
-- 		{ name = 'h4_nw_ipl_03', enabled = true },
-- 		{ name = 'h4_nw_ipl_04', enabled = true },
-- 		{ name = 'h4_nw_ipl_05', enabled = true },
-- 		{ name = 'h4_nw_ipl_06', enabled = true },
-- 		{ name = 'h4_nw_ipl_07', enabled = true },
-- 		{ name = 'h4_nw_ipl_08', enabled = true },
-- 		{ name = 'h4_nw_ipl_09', enabled = true },
-- 		{ name = 'h4_se_ipl_00', enabled = true },
-- 		{ name = 'h4_se_ipl_01', enabled = true },
-- 		{ name = 'h4_se_ipl_02', enabled = true },
-- 		{ name = 'h4_se_ipl_03', enabled = true },
-- 		{ name = 'h4_se_ipl_04', enabled = true },
-- 		{ name = 'h4_se_ipl_05', enabled = true },
-- 		{ name = 'h4_se_ipl_06', enabled = true },
-- 		{ name = 'h4_se_ipl_07', enabled = true },
-- 		{ name = 'h4_se_ipl_08', enabled = true },
-- 		{ name = 'h4_se_ipl_09', enabled = true },
-- 		{ name = 'h4_sw_ipl_00', enabled = true },
-- 		{ name = 'h4_sw_ipl_01', enabled = true },
-- 		{ name = 'h4_sw_ipl_02', enabled = true },
-- 		{ name = 'h4_sw_ipl_03', enabled = true },
-- 		{ name = 'h4_sw_ipl_04', enabled = true },
-- 		{ name = 'h4_sw_ipl_05', enabled = true },
-- 		{ name = 'h4_sw_ipl_06', enabled = true },
-- 		{ name = 'h4_sw_ipl_07', enabled = true },
-- 		{ name = 'h4_sw_ipl_08', enabled = true },
-- 		{ name = 'h4_sw_ipl_09', enabled = true },
-- 		{ name = 'h4_islandx_placement_01', enabled = true },
-- 		{ name = 'h4_islandx_placement_02', enabled = true },
-- 		{ name = 'h4_islandx_placement_03', enabled = true },
-- 		{ name = 'h4_islandx_placement_04', enabled = true },
-- 		{ name = 'h4_islandx_placement_05', enabled = true },
-- 		{ name = 'h4_islandx_placement_06', enabled = true },
-- 		{ name = 'h4_islandx_placement_07', enabled = true },
-- 		{ name = 'h4_islandx_placement_08', enabled = true },
-- 		{ name = 'h4_islandx_placement_09', enabled = true },
-- 		{ name = 'h4_islandx_placement_10', enabled = true },
-- 		{ name = 'h4_mph4_island_placement', enabled = true }
-- }

-- Citizen.CreateThread(
-- function()
-- 	for k,v in pairs(Config.Island) do
-- 		if v.enabled then
-- 			RequestIpl(v.name)
-- 		else
-- 			if IsIplActive(v.name) then
-- 				RemoveIpl(v.name)
-- 			end
-- 		end
-- 	end
-- 	loadHangar()
-- 	while true do
-- 		nearIsland()
-- 		Wait(2500)
-- 	end
-- end)

-- Citizen.CreateThread(
-- function()
-- 	while true do
-- 		if Config.EnableRadar then
-- 			enableRadar()
-- 		else
-- 			break
-- 		end
-- 		Wait(1)
-- 	end
-- end)

-- function loadHangar()
-- 	if IsIplActive('h4_islandairstrip') and IsIplActive('h4_mph4_airstrip_interior_0_airstrip_hanger') then
-- 	local interiorId = GetInteriorAtCoordsWithType(4439.823, -4461.717, 4.7,'h4_airstrip_hanger')
-- 		ActivateInteriorEntitySet(interiorId,'island_hanger_padlock_props') 
-- 			if IsValidInterior(interiorId) and IsInteriorEntitySetActive(interiorId,'island_hanger_padlock_props') then
-- 			ActivateInteriorEntitySet(interiorId,'h4_island_padlock_props')	
-- 			PinInteriorInMemory(interiorId)
-- 			RefreshInterior(interiorId)
-- 		end
-- 	end
-- end

-- function nearIsland()
-- 	local nearIsland = false
-- 	local distanceTo = vector3(4840.571, -5174.425, 2.0)
-- 	local Player = GetEntityCoords(PlayerPedId())
-- 	if #(Player - distanceTo) < 2000 then
-- 		nearIsland = true
-- 		SetScenarioGroupEnabled('Heist_Island_Peds', true)
-- 		SetScenarioGroupEnabled('Heist_Island_Peds', true)
-- 		SetAmbientZoneListStatePersistent('AZL_DLC_Hei4_Island_Zones', true, true)
-- 		SetAmbientZoneListStatePersistent('AZL_DLC_Hei4_Island_Disabled_Zones', false, true)
-- 		SetAiGlobalPathNodesType(1)
-- 	else
--      	nearIsland = false
-- 		SetScenarioGroupEnabled('Heist_Island_Peds', false)
-- 		SetAmbientZoneListStatePersistent('AZL_DLC_Hei4_Island_Zones', false, false)
-- 		SetAmbientZoneListStatePersistent('AZL_DLC_Hei4_Island_Disabled_Zones', false, false)
-- 		SetAiGlobalPathNodesType(0)
-- 	end

-- 	if nearIsland and Config.SetAudioFlag then
-- 		SetAudioFlag('PlayerOnDLCHeist4Island', true)
-- 	else
-- 		ResetPedAudioFlags(GetPlayerPed())
-- 		SetAudioFlag('PlayerOnDLCHeist4Island', false)
-- 	end

-- 	if nearIsland and Config.OceanScaler then
-- 		SetDeepOceanScaler(0.1)
-- 	else
-- 		ResetDeepOceanScaler()
-- 	end
-- end

-- function enableRadar()
-- 	SetRadarAsExteriorThisFrame()
-- 	SetRadarAsInteriorThisFrame('h4_fake_islandx', vec(4700.0, -5145.0), 0, 0)
-- end