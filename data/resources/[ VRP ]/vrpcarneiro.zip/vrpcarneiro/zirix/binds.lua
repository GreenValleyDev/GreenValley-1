binds = {}

binds.accept = 'y'
binds.decline = 'n'

binds.up = 'UP'
binds.down = 'DOWN'
binds.left = 'LEFT'
binds.right = 'RIGHT'

binds.select = 'RETURN'
binds.cancel = 'BACK'

binds.use = 'E'
binds.trunkchest = 'O'

binds.identity = 'F11'

binds.inventory = 'OEM_3' -- aspas

binds.carlock = 'L'

binds.belt = 'G'